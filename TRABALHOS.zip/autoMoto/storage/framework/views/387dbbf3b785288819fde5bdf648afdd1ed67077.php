<?php $__env->startSection('content'); ?>
	

			<!-- start banner Area -->
			<section class="banner-area relative" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">
					<div class="row fullscreen d-flex align-items-center justify-content-center">
						<div class="banner-content col-lg-12">
							<section class="submit-area section-gap">
								<div class="container">
										<h2 class="mb-10 text-white">Já é cadastrado em nosso site?</h2><br>
									<div class="row">
											
										<div class="col-lg-6">

											<div class="submit-left">
												<h4>Entrar na conta</h4>
												<p>
													Para que você possa efetuar sua compra, faça o seu Login.
												</p>
												<a href="<?php echo e(route('login')); ?>" class="primary-btn header-btn">Entrar</a>	
											</div>
										</div>
										<div class="col-lg-6 ">
											<div class="submit-left">
												<h4>Crie uma conta Agora!!!</h4>
												<p>
													Não perca o seu tempo!! Cadastre-se em nosso site
												</p>
												<a href="<?php echo e(route('register')); ?>" class="primary-btn header-btn">Cadastrar</a>		
											</div>			
										</div>
				
									</div>
								</div>	
							</section>
						<!--	<div class="title text-center">
								<h2 class="mb-10 text-white">Já é cadastrado em nosso site?</h2>
								<p class="text-white">para melhores serviços, é necessário o cadastramento para realizar as compras para a sua moto</p>
								<a class="primary-btn" href="#">Entrar</a>
								<a class="primary-btn" href="#">Criar uma nova conta</a>
							</div> -->
						</div>											
					</div>
				</div>
			</section>
			<!-- End banner Area -->	

			
			<!-- Start callto-action Area -->
			<section class="callto-action-area section-gap" id="join">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="menu-content col-lg-9">
							
						</div>
					</div>	
				</div>	
			</section>
			<!-- End calto-action Area -->

			<!-- Start download Area -->
			<section class="download-area section-gap" id="app">
				<div class="container">
					<div class="row">
						<div class="col-lg-6 download-left">
							<img class="img-fluid" src="img/d1.png" alt="">
						</div>
						<div class="col-lg-6 download-right">
							<h1>Faça Download do nosso app<br>
							No seu aparelho Android</h1>
							<p class="subs">
							Para melhor atendimento, criamos um aplicativo para melhor mobilidade e facilidade nas compras de seus equipametos para a sua moto.	
							</p>
							<div class="d-flex flex-row">
								<div class="buttons">
									<i class="fa fa-android" aria-hidden="true"></i>
									<div class="desc">
										<a href="#">
											<p>
												<span>Disponível</span> <br>
												na Play Store
											</p>
										</a>
									</div>
								</div>									
							</div>						
						</div>
					</div>
				</div>	
			</section>
			<!-- End download Area -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>