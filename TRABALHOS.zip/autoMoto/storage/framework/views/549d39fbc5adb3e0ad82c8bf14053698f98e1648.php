<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="shortcut icon" href="img/fav.png">
    <meta name="author" content="codepixer">
	<meta name="description" content="">
	<meta name="keywords" content="">	    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">     

     <title>Auto Motors</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/linearicons.css">
	    <link rel="stylesheet" href="css/font-awesome.min.css">
	    <link rel="stylesheet" href="css/bootstrap.css">
	    <link rel="stylesheet" href="css/magnific-popup.css">
	    <link rel="stylesheet" href="css/nice-select.css">					
	    <link rel="stylesheet" href="css/animate.min.css">
	    <link rel="stylesheet" href="css/owl.carousel.css">
	    <link rel="stylesheet" href="css/main.css">
	    <link rel="stylesheet" href="css/linearicons.css">
		<!-- Scripts -->
    	<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    	<!-- Fonts -->
    	<link rel="dns-prefetch" href="//fonts.gstatic.com">
    	<link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">
    	<!-- Styles -->
    	<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>


<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">
            <div id="logo">
					  <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="img/logo_auto.png" alt="" width=70 height=50 title="" /></a>
				        
			</div>
               
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    
                    <ul class="navbar-nav ml-auto">

                         <ul class="nav-menu">
				          <li class="menu-active"><a href="welcome.html">início</a></li>
				          <li><a href="<?php echo e(url('/sobre')); ?>">Sobre nós</a></li>
				          <li><a href="<?php echo e(url('/pesquisa')); ?>">Categorias</a></li>
						  
				            <ul>
								<li><a href="elements.html">elements</a></li>
								<li><a href="search.html">search</a></li>
								<li><a href="single.html">single</a></li>
				            </ul>
				          </li>
						  
						  
						              
          						
		</ul>

                    
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                         
                            <?php if(Route::has('register')): ?> 

                            <div id="logo">	
                                <a class="navbar-brand" href="<?php echo e(url('/verifica')); ?>"><img src="img/login.png" alt="" width=70 height=50 title="" /></a>  
                            </div>                              
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>
                                

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">

                                     <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                                        <?php echo e(__('Inserir anúncio')); ?>

                                    </a>

                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                                        <?php echo e(__('Minhas compras')); ?>

                                    </a>

                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

    

        <main class="py-4">
     





         
        
        


            <?php echo $__env->yieldContent('content'); ?>






<footer class="footer-area section-gap">
<div class="container">
<div class="row">
<div class="col-lg-3  col-md-12">
<div class="single-footer-widget">
    <h6>O que procura no momento?</h6>
	<ul class="footer-nav">
		<li><a href="<?php echo e(url('/')); ?>">início</a></li>
		<li><a href="<?php echo e(url('/sobre')); ?>">sobre nós</a></li>
		<li><a href="<?php echo e(url('/pesquisa')); ?>">categorias</a></li>
		<li><a href="#">Entre em Contato</a></li>
	</ul>
</div>
</div>
<div class="col-lg-6  col-md-12 col-xl-9">
<div class="single-footer-widget newsletter">
	<h6>Fique por dentro das promoções</h6>
	<p>não trabalhamos com propaganda chata ou spam, esta ferramenta irá te notificar de todas promoções do seu interesse</p>
<div id="mc_embed_signup">
	<form target="_blank" novalidate="true" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01" method="get" class="form-inline">

<div class="form-group row" style="width: 100%">
<div class="col-lg-8 col-md-12">
    <input name="EMAIL" placeholder="Entre com seu Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Email '" required="" type="email">

<div style="position: absolute; left: -5000px;">
	<input name="b_36c4fd991d266f23781ded980_aefe40901a" tabindex="-1" value="" type="text">
</div>
</div> 
			
<div class="col-lg-4 col-md-12">
	<button class="nw-btn primary-btn">Inscrever<span class="lnr lnr-arrow-right"></span></button>
</div> 
</div>		
<div class="info"></div>
</form>
</div>		
</div>
</div>
											
</div>

<div class="row footer-bottom d-flex justify-content-between">
	<p class="col-lg-8 col-sm-12 footer-text m-0 text-white">						
        Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
	</p>
<div class="col-lg-4 col-sm-12 footer-social">
	<a href="#"><i class="fa fa-facebook"></i></a>
	<a href="#"><i class="fa fa-twitter"></i></a>
	<a href="#"><i class="fa fa-dribbble"></i></a>
	<a href="#"><i class="fa fa-behance"></i></a>
</div>
</div>
</div>
</footer>

<script src="js/vendor/jquery-2.2.4.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="js/vendor/bootstrap.min.js"></script>			
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
<script src="js/easing.min.js"></script>			
<script src="js/hoverIntent.js"></script>
<script src="js/superfish.min.js"></script>	
<script src="js/jquery.ajaxchimp.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>	
<script src="js/owl.carousel.min.js"></script>			
<script src="js/jquery.sticky.js"></script>
<script src="js/jquery.nice-select.min.js"></script>			
<script src="js/parallax.min.js"></script>		
<script src="js/mail-script.js"></script>	
<script src="js/main.js"></script>	

 


        </main>
    </div>


</body>
</html>
