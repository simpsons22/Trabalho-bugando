<?php $__env->startSection('conteudo'); ?>

  <section class="banner-area relative" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
								Entrar				
							</h1>	
							<p class="text-white"><a href="index.html">Início </a>  <span class="lnr lnr-arrow-right"></span>  <a href="contact.html"> Entrar</a></p>
						</div>											
					</div>
				</div>
			</section>
			<!-- End banner Area -->	

			<!-- Start contact-page Area -->
			<section class="contact-page-area section-gap">
				<div class="container">
					<div class="row">
						
						<div class="col-lg-8 offset-xl-2">
							<form class="form-area " id="myForm" action="mail.php" method="post" class="contact-form text-right">
								<div class="row">	
									<div class="col-lg-12 form-group">
                                        
										<input name="name" placeholder="Ensira o seu nome" onfocus="this.placeholder = ''" onblur="this.placeholder = ''" class="common-input mb-20 form-control" required="" type="text">
										<input name="password" placeholder="Digite a senha" onfocus="this.placeholder = ''" onblur="this.placeholder = ''" class="common-input mb-20 form-control" required="" type="password">
										
												
													<div class="mt-20 alert-msg" style="text-align: left;"></div>
										<button class="primary-btn mt-20 text-white" style="float: right;"><a href="indexl.html" color="white" >Entrar Agora</a></button>
										</div>
										
										
									</div>
								</div>
							</form>	
						</div>
					</div>
				</div>	
			</section>
			

<?php $__env->stopSection(); ?>
<?php echo $__env->make('shared.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>