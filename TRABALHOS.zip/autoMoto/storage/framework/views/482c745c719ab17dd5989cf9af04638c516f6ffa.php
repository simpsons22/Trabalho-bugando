<?php $__env->startSection('conteudo'); ?>




			<!-- start banner Area -->
			<section class="banner-area relative" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">
					<div class="row fullscreen d-flex align-items-center justify-content-center">
						<div class="banner-content col-lg-12">
							<h2 class="text-white">
								Diga-nos qual peça você procura				
							</h2>	
							<form action="search.html" class="serach-form-area">
								<div class="row justify-content-center form-wrap">
								<!--	<div class="col-lg-4 form-cols">
										<input type="text" class="form-control" name="search" placeholder="what are you looging for?">
									</div> -->
									
									<div class="col-lg-3 form-cols">
										<div class="default-select" id="default-selects">
											<select>
												<option value="1">Selecione a marca</option>
												<option value="2">...</option>
										<!--		<option value="3">Rajshahi</option>
												<option value="4">Barishal</option>
												<option value="5">Noakhali</option>
											--></select>
										</div>
									</div>

									<div class="col-lg-3 form-cols">
										<div class="default-select" id="default-selects">
											<select>
												<option value="1">Selecione o modelo</option>
												<option value="2">...</option>
											<!--	<option value="3">Rajshahi</option>
												<option value="4">Barishal</option>
												<option value="5">Noakhali</option>-->
											</select>
										</div>
									</div>
									<div class="col-lg-3 form-cols">
										<div class="default-select" id="default-selects2">
											<select>
												<option value="1">Selecione a peça</option>
												<option value="2">...</option>
												<!-- <option value="3">Technology</option>
												<option value="4">Goverment</option>
												<option value="5">Development</option>-->
											</select>
										</div>										
									</div>
									<div class="col-lg-2 form-cols">
									    <button type="button" class="btn btn-info">
									      <span class="lnr lnr-magnifier"></span> Procurar
									    </button>
									</div>								
								</div>
							</form>	
							<p class="text-white">Caso não ache o modelo ou peça desejada, mande um feedback </p>
						</div>											
					</div>
				</div>
			</section>
			<!-- End banner Area -->	

			<!-- Start features Area -->
			<section class="features-area">
				<div class="container">
					<div class="row">
						<div class="col-lg-3 col-md-6">
							<div class="single-feature">
								<h4>Pesquise</h4>
								<p>
									com nosso vasto banco de dados preenchido com as melhores peças de motocicleta
								</p>
							</div>
						</div>
						<div class="col-lg-3 col-md-6">
							<div class="single-feature">
								<h4>Compare</h4>
								<p>
									Daremos a você mais opções de peças para escolha e comparação de preço
								</p>
							</div>
						</div>
						<div class="col-lg-3 col-md-6">
							<div class="single-feature">
								<h4>Selecione</h4>
								<p>
									Selecione a peça desejada para efetuar sua compra pelos dados do seu cartão
								</p>
							</div>
						</div>
						<div class="col-lg-3 col-md-6">
							<div class="single-feature">
								<h4>Aguarde seu produto</h4>
								<p>
									Feito isso, nossa equipe estará enviando a peça desejada para o destino selecionado
								</p>
							</div>
						</div>																		
					</div>
				</div>	
			</section>
			<!-- End features Area -->
			
			<!-- Start callto-action Area -->
			<section class="callto-action-area section-gap" id="join">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="menu-content col-lg-9">
							<div class="title text-center">
								<h1 class="mb-10 text-white">Já é cadastrado em nosso site?</h1>
								<p class="text-white">para melhores serviços, é necessário o cadastramento para realizar as compras para a sua moto</p>
								<a class="primary-btn" href="login.html">Entrar</a>
								<a class="primary-btn" href="cadastrar.html">Criar uma nova conta</a>
							</div>
						</div>
					</div>	
				</div>	
			</section>
			<!-- End calto-action Area -->

			<!-- Start download Area -->
			<section class="download-area section-gap" id="app">
				<div class="container">
					<div class="row">
						<div class="col-lg-6 download-left">
							<img class="img-fluid" src="img/d1.png" alt="">
						</div>
						<div class="col-lg-6 download-right">
							<h1 class="blanco">Faça Download do nosso app<br>
							No seu aparelho Android</h1>
							<p class="subs">
							Para melhor atendimento, criamos um aplicativo para melhor mobilidade e facilidade nas compras de seus equipametos para a sua moto.	
							</p>
							<div class="d-flex flex-row">
								<div class="buttons">
									<i class="fa fa-android" aria-hidden="true"></i>
									<div class="desc">
										<a href="https://www.youtube.com/watch?v=q6EoRBvdVPQ">
											<p>
												<span>Disponível</span> <br>
												na Play Store
											</p>
										</a>
									</div>
								</div>									
							</div>						
						</div>
					</div>
				</div>	
			</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('shared.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>