<?php $__env->startSection('content'); ?>

			<!-- start banner Area -->
			<section class="banner-area relative" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">
					<div class="row search-page-top d-flex align-items-center justify-content-center">
												<div class="banner-content col-lg-12">
							<h2 class="text-white">
								Diga-nos qual peça você procura				
							</h2>	
							<form action="search.html" class="serach-form-area">
								<div class="row justify-content-center form-wrap">
								<!--	<div class="col-lg-4 form-cols">
										<input type="text" class="form-control" name="search" placeholder="what are you looging for?">
									</div> -->
									
									<div class="col-lg-3 form-cols">
										<div class="default-select" id="default-selects">
											<select>
												<option value="1">Selecione a marca</option>
												<option value="2">...</option>
										<!--		<option value="3">Rajshahi</option>
												<option value="4">Barishal</option>
												<option value="5">Noakhali</option>
											--></select>
										</div>
									</div>

									<div class="col-lg-3 form-cols">
										<div class="default-select" id="default-selects">
											<select>
												<option value="1">Selecione o modelo</option>
												<option value="2">...</option>
											<!--	<option value="3">Rajshahi</option>
												<option value="4">Barishal</option>
												<option value="5">Noakhali</option>-->
											</select>
										</div>
									</div>
									<div class="col-lg-3 form-cols">
										<div class="default-select" id="default-selects2">
											<select>
												<option value="1">Selecione a peça</option>
												<option value="2">...</option>
												<!-- <option value="3">Technology</option>
												<option value="4">Goverment</option>
												<option value="5">Development</option>-->
											</select>
										</div>										
									</div>
									<div class="col-lg-2 form-cols">
									    <button type="button" class="btn btn-info">
									      <span class="lnr lnr-magnifier"></span> Procurar
									    </button>
									</div>								
								</div>
							</form>	
							<p class="text-white">Caso não ache o modelo ou peça desejada, mande um feedback </p>
						</div>
				</div>
			</section>
			<!-- End banner Area -->	
			
			<!-- Start post Area -->
			<section class="post-area section-gap">
				<div class="container">
					<div class="row justify-content-center d-flex">
						<div class="col-lg-8 post-list">
						  <div class="single-post d-flex flex-row">
								<div class="thumb">
									<img src="img/post.png" alt="">								</div>
								<div class="details">
									<div class="title d-flex flex-row justify-content-between">
										<div class="titles">
											<a href="single.html"><h4>produto</h4></a>					
										</div>
										<ul class="btns">
											
											<li><a href="#">Comprar</a></li>
										</ul>
									</div>
								  <p>
										Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc ididunt ut dolore magna aliqua.
								  </p>
									<h5>Job Nature: Full time</h5>
</div>
							</div>aaaa
							<div class="single-post d-flex flex-row">
								<div class="thumb">
									<img src="img/post.png" alt="">								</div>
							  <div class="details">
							    <div class="title d-flex flex-row justify-content-between">
								  <div class="titles">
								    <a href="single.html"><h4>Creative Art Designer</h4></a>
																
										</div>
									  <ul class="btns">
											
										  <li><a href="#">Comprar</a></li>
									  </ul>
									</div>
									<p>
										Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc ididunt ut dolore magna aliqua.
									</p>
							    <h5>Job Nature: Full time</h5>
</div>
							</div>
							<div class="single-post d-flex flex-row">
								<div class="thumb">
									<img src="img/post.png" alt="">								</div>
							  <div class="details">
							    <div class="title d-flex flex-row justify-content-between">
								  <div class="titles">
											<a href="single.html"><h4>Creative Art Designer</h4></a>
											<h6>Premium Labels Limited</h6>					
								    </div>
									  <ul class="btns">
											
										  <li><a href="#">Comprar</a></li>
									  </ul>
									</div>
									<p>
										Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc ididunt ut dolore magna aliqua.
									</p>
								<h5>Job Nature: Full time</h5>
</div>
							</div>		
							<div class="single-post d-flex flex-row">
								<div class="thumb">
									<img src="img/post.png" alt="">								</div>
							  <div class="details">
							    <div class="title d-flex flex-row justify-content-between">
								  <div class="titles">
											<a href="single.html"><h4>Creative Art Designer</h4></a>
											<h6>Premium Labels Limited</h6>					
								    </div>
									  <ul class="btns">
											
										  <li><a href="#">Comprar</a></li>
									  </ul>
									</div>
									<p>
										Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc ididunt ut dolore magna aliqua.
									</p>
								<h5>Job Nature: Full time</h5>
</div>
							</div>
							<div class="single-post d-flex flex-row">
								<div class="thumb">
									<img src="img/post.png" alt="">								</div>
							  <div class="details">
								<div class="title d-flex flex-row justify-content-between">
								  <div class="titles">
											<a href="single.html"><h4>Creative Art Designer</h4></a>
											<h6>Premium Labels Limited</h6>					
									</div>
									<ul class="btns">
											
										<li><a href="#">Apply</a></li>
								    </ul>
								  </div>
									<p>
										Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc ididunt ut dolore magna aliqua.
									</p>
								<h5>Job Nature: Full time</h5>
</div>
							</div>
							<div class="single-post d-flex flex-row">
								<div class="thumb">
									<img src="img/post.png" alt="">								</div>
							  <div class="details">
								<div class="title d-flex flex-row justify-content-between">
								  <div class="titles">
											<a href="single.html"><h4>Creative Art Designer</h4></a>
											<h6>Premium Labels Limited</h6>					
									</div>
									<ul class="btns">
											
										<li><a href="#">Apply</a></li>
								    </ul>
								  </div>
									<p>
										Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc ididunt ut dolore magna aliqua.
									</p>
								<h5>Job Nature: Full time</h5>
</div>
							</div>															
							<div class="single-post d-flex flex-row">
								<div class="thumb">
									<img src="img/post.png" alt="">								</div>
							  <div class="details">
							    <div class="title d-flex flex-row justify-content-between">
								  <div class="titles">
											<a href="single.html"><h4>Creative Art Designer</h4></a>
											<h6>Premium Labels Limited</h6>					
								    </div>
									  <ul class="btns">
											
										  <li><a href="#">Apply</a></li>
									  </ul>
									</div>
									<p>
										Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc ididunt ut dolore magna aliqua.
									</p>
								<h5>Job Nature: Full time</h5>
</div>
							</div>	

						</div>
</div>
				</div>	
			</section>
			<!-- End post Area -->

			<!-- Start callto-action Area -->
			<section class="callto-action-area section-gap">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="menu-content col-lg-9">
							<div class="title text-center">
								<h1 class="mb-10 text-white">Já é cadastrado em nosso site?</h1>
								<p class="text-white">para melhores serviços, é necessário o cadastramento para realizar as compras para a sua moto</p>
								<a class="primary-btn" href="login.html">Entrar</a>
								<a class="primary-btn" href="cadastrar.html">Criar uma nova conta</a>
							</div>
						</div>
					</div>		
				</div>	
			</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>