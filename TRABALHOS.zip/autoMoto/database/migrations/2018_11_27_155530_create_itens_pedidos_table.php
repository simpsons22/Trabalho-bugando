<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateItensPedidosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('itens_pedidos', function (Blueprint $table) {
            $table->unsignedInteger('pedidos_id');
            $table->foreign('pedidos_id')->references('id')->on('pedidos')->onDelete('cascade');
            
            $table->unsignedInteger('modelo_pecas_modelos_id');
            $table->foreign('modelo_pecas_modelos_id')->references('modelos_id')->on('modelo_pecas')->onDelete('cascade');

            $table->unsignedInteger('modelo_pecas_pecas_id');
            $table->foreign('modelo_pecas_pecas_id')->references('pecas_id')->on('modelo_pecas')->onDelete('cascade');

            $table->integer('qtdpecas');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('itens_pedidos');
    }
}
