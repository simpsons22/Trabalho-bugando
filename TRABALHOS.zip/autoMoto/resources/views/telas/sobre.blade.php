@extends('layouts.app')

@section('content')



			<section class="banner-area relative" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
								Sobre Nós				
						  </h1>	
							<p class="text-white link-nav"><a href="index.html">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="about-us.html"> Sobre Nós</a></p>
						</div>											
					</div>
				</div>
			</section>
			<!-- End banner Area -->	
				
			<!-- Start service Area -->
			<section class="service-area section-gap" id="service">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="col-md-8 pb-40 header-text">
							<h1>Porque nos escolher?</h1>
							<p>
								Caso ainda esteja em dúvida, daremospara você motivos para que escolha nosso serviços
						  </p>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-6">
							<div class="single-service">
								<h4><span class="lnr lnr-user"></span>Fidelidade e segurança</h4>
								<p>
									garantimos total segurança e suporte para o usuário de nosso site para um ótimo uso e assim a satisfação do cliente!!
								</p>
							</div>
						</div>
						<div class="col-lg-4 col-md-6">
							<div class="single-service">
								<h4><span class="lnr lnr-license"></span>Parcerias com as concecionárias</h4>
								<p>
									para maior qualidade dos produtos, temos colaboradores de fábricas oficiais e comerciantes de qualidade
								</p>								
							</div>
						</div>
						<div class="col-lg-4 col-md-6">
							<div class="single-service">
								<h4><span class="lnr lnr-phone"></span>Ótimo suporte</h4>
								<p>
									Nós prezamos para sua opinião e escolha, portanto a qualquer momento e dúvida, estaremos pronto para ajudar seja qual for o questionamento
							  </p>								
							</div>
						</div>
						<div class="col-lg-4 col-md-6">
							<div class="single-service">
								<h4><span class="lnr lnr-rocket"></span>Entregas rápidas e seguras</h4>
								<p>
									Pensamos a respeito de um dos piores vilões dos usuários online, ENTREGA!!!, você receberá seu pedido o mais rápido possível.
							  </p>				
							</div>
						</div>
						<div class="col-lg-4 col-md-6">
							<div class="single-service">
								<h4><span class="lnr lnr-diamond"></span>Qualidade dos Produtos</h4>
								<p>
									não pense que mexemos com peças genéricas ou réplicas sem valor, prezamos pela qualidade pensando exclusivamento no usuário
							  </p>								
							</div>
						</div>
						<div class="col-lg-4 col-md-6">
							<div class="single-service">
								<h4><span class="lnr lnr-bubble"></span>Resultados Positivos</h4>
								<p>
									Nosso site após ficar pronto foi apresentado, testado e assim apresentado para minha mãe, e adivinha? ela amou!!!

								</p>									
							</div>
						</div>						
					</div>
				</div>	
			</section>
			<!-- End service Area -->						

			<!-- Start feature Area -->
			<section class="feature-area">
				<div class="container-fluid">
					<div class="row justify-content-center align-items-center">
						<div class="col-lg-3 feat-img no-padding">
							<img class="img-fluid" src="img/pages/f1.jpg" alt="">
						</div>
						<div class="col-lg-3 no-padding feat-txt">
							<h6 class="text-uppercase text-white">Um pouco sobre a equipe</h6>
							<h1>Quem somo nós?</h1>
							<p>
								Somos Programadores que com um objetivo e dedicação, corremos atrás a partir do nosso conhecimento na área da progrmação, juntando duas coisas que de fato gostamos
							</p>
						</div>
						<div class="col-lg-3 feat-img no-padding">
							<img class="img-fluid" src="img/pages/f2.jpg" alt="">							
						</div>
						<div class="col-lg-3 no-padding feat-txt">
							<h6 class="text-uppercase text-white">ideias e inspirações</h6>
							<h1>Como surgiu a ideia?</h1>
							<p>
								A partir da necessidade de criar um site, mesclamos um desejo de empreender e desenvolver a partir de uma coisa que gostamos pensando nesse detalhe
							</p>
						</div>
					</div>
				</div>	
			</section>
			<!-- End feature Area -->

			<!-- Start team Area -->
			<section class="team-area section-gap" id="team">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="menu-content pb-70 col-lg-8">
							<div class="title text-center">
								<h1 class="mb-10">Profissionais que trabalharam no site</h1>
								<p>Esses são os desenvolvedores que você concerteza quer como seus amigos!</p>
							</div>
						</div>
					</div>						
					<div class="row justify-content-center d-flex align-items-center">
						<div class="col-md-3 single-team">
						    <div class="thumb">
						        <img class="img-fluid" src="img/pages/t1.jpg" alt="">
						        <div class="align-items-center justify-content-center d-flex">
									<a href="#"><i class="fa fa-facebook"></i></a>
									<a href="#"><i class="fa fa-twitter"></i></a>
									<a href="#"><i class="fa fa-linkedin"></i></a>
						        </div>
						    </div>
						    <div class="meta-text mt-30 text-center">
							    <h4>Roniclei Santos</h4>
							    <p>Programador lider<br>
									Desenvolvedor back-end<br>
							  Banco de Dados e rotas</p>
						    </div>
						</div>
						<div class="col-md-3 single-team">
						    <div class="thumb">
						        <img class="img-fluid" src="img/pages/t2.jpg" alt="">
						        <div class="align-items-center justify-content-center d-flex">
									<a href="#"><i class="fa fa-facebook"></i></a>
									<a href="#"><i class="fa fa-twitter"></i></a>
									<a href="#"><i class="fa fa-linkedin"></i></a>
						        </div>
						    </div>
						    <div class="meta-text mt-30 text-center">
							    <h4>Kernell Tozi</h4>
							    <p>Programador<br>
									Desenvolvedor Front-End<br>
									Desenvolvedor da estrutura do site</p>
									
					      </div>
						</div>	
						<div class="col-md-3 single-team">
						    <div class="thumb">
						        <img class="img-fluid" src="img/pages/t3.jpg" alt="">
						        <div class="align-items-center justify-content-center d-flex">
									<a href="#"><i class="fa fa-facebook"></i></a>
									<a href="#"><i class="fa fa-twitter"></i></a>
									<a href="#"><i class="fa fa-linkedin"></i></a>
						        </div>
						    </div>
						    <div class="meta-text mt-30 text-center">
							    <h4>Edivaldo Auer</h4>
							    <p>Apoio Moral<br>
									Crítico Proficional<br>
									colega da cadeira do lado</p>
						    </div>
						</div>
</div>
				</div>	
			</section>
			<!-- End team Area -->			


			<!-- Start callto-action Area -->
			<section class="callto-action-area section-gap">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="menu-content col-lg-9">
							<div class="title text-center">
								<h1 class="mb-10 text-white">Já é cadastrado no nosso site?</h1>
								<p class="text-white">Para poder efetuar compra, você deve efetuar a compra do seu produto, deverá fazer o cadastro ou Login no site</p>
								<a class="primary-btn" href="{{ route('register') }}">Cadastrar</a>
								<a class="primary-btn" href="{{ route('login') }}">Entrar</a>
							</div>
						</div>
					</div>	
				</div>	
			</section>




@endsection