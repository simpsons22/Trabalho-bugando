<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\itensPedido;

class itensPedido extends Model
{
    protected $fillable = [
        'qtdPecas'
    ];
}
