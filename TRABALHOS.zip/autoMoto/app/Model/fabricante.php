<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\fabricante;

class fabricante extends Model
{
    protected $fillable = [
        'nome','email','telefone','logradouro','cidade','uf'
    ];
}
