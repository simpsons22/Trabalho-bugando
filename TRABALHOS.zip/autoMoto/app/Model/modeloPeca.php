<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\modeloPeca;

class modeloPeca extends Model
{
    protected $fillable = [
        
    ];
}
