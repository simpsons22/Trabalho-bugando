<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\modelo;

class modelo extends Model
{
    protected $fillable = [
        'nome','descricao','cilindrada','ano'
    ];
}
