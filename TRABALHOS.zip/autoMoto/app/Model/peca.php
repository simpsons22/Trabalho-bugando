<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\peca;

class peca extends Model
{
    protected $fillable = [
        'nome','descricao','marcaPeca','codFabricacao','valorEntrada','valorVenda','qtdEstoque'
    ];
}
