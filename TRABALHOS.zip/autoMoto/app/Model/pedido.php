<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\pedido;

class pedido extends Model
{
    protected $fillable = [
        'valor','dataCompra','dataEnvio','formaPagamento'
    ];
}
